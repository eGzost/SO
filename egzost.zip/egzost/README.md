Local development:

- Have dotnet sdk 8.0 installed
- Run any lab using `dotnet run --project=<path>`. Example: `dotnet run --project=lab1`
